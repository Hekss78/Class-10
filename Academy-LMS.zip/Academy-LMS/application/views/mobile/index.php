<!DOCTYPE html>
<html>

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5.0, minimum-scale=0.86">
	<?php include 'includes_top.php'; ?>
</head>

<body>
	<div class="container-fluid">
		<!-- HEADER -->
		<?php include $page_name . '.php'; ?>
	</div>
	<!-- all the js files -->
	<?php include 'includes_bottom.php'; ?>
	<?php include 'payment_model.php'; ?>
</body>

</html>
